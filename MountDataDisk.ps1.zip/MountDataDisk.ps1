﻿Configuration MountDataDisk
{
    $Num="3"
    $tipo= "MBR"
    Initialize-Disk -Number $Num -PartitionStyle $tipo 
}