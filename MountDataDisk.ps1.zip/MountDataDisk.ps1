﻿Configuration MountDataDisk
{
    param 
   ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 

    Node localhost
    {

         Script script1
        { 
            SetScript =  {
		        $Num="4"
                $tipo= "MBR"
                Initialize-Disk -Number $Num -PartitionStyle $tipo	
            }
            
        }
         
    }
}