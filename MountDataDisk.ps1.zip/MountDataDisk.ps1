﻿Configuration MountDataDisk
{
    param 
   ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 

    Import-DscResource -ModuleName xDisk

    Node localhost
    {
        
		$Num="4"
        $tipo= "MBR"
        Initialize-Disk -Number $Num -PartitionStyle $tipo	       
            
    }
}