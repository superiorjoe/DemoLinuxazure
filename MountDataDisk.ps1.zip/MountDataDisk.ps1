﻿$Num="2"
$tipo= "MBR"
Initialize-Disk -Number $Num -PartitionStyle $tipo 