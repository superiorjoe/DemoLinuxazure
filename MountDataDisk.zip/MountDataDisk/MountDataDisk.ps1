﻿Configuration MountDataDisk
{
    param 
   ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 
    Import Module xDisk

    Node localhost
    {

       xDisk Disk
       {
            DiskNumber = "4"
       }      
    }
}